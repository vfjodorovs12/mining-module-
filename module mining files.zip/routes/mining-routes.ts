import { Router } from "express";
import { startMining, stopMining } from "../controllers/mining-controller";

const router = Router();

router.post("/start", startMining);
router.post("/stop", stopMining);

export default router;