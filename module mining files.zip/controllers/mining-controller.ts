import { Request, Response } from "express";

export const startMining = (req: Request, res: Response) => {
  res.send("Mining started!");
};

export const stopMining = (req: Request, res: Response) => {
  res.send("Mining stopped!");
};