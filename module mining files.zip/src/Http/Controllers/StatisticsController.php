<?php

namespace App\Http\Controllers\Mining;

use App\Http\Controllers\Controller;
use App\Models\MiningRecord;
use Illuminate\Http\Request;

class StatisticsController extends Controller
{
    public function index()
    {
        $summary = MiningRecord::selectRaw('SUM(quantity) as total_ore, COUNT(*) as total_mining_sessions')
                                ->get()
                                ->first();

        return view('mining.statistics.index', [
            'summary' => $summary,
        ]);
    }

    public function detailed(Request $request)
    {
        $records = MiningRecord::query();

        if ($request->has('character_id')) {
            $records->where('character_id', $request->input('character_id'));
        }

        if ($request->has('ore_type')) {
            $records->where('ore_type', $request->input('ore_type'));
        }

        $records = $records->paginate(20);

        return view('mining.statistics.detailed', [
            'records' => $records,
        ]);
    }
}