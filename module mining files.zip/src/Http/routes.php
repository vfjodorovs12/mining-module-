<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Mining\StatisticsController;
use App\Http\Controllers\Mining\MoonController;
use App\Http\Controllers\Mining\InvoiceController;
use App\Http\Controllers\Mining\SettingsController;

Route::group(['prefix' => 'mining', 'middleware' => ['auth']], function () {
    Route::get('statistics/detailed', [StatisticsController::class, 'detailed'])->name('mining.statistics.detailed')
        ->middleware('can:mining.view.detailed');

    Route::get('statistics', [StatisticsController::class, 'index'])->name('mining.statistics');

    Route::resource('moons', MoonController::class)->middleware('can:mining.manage');

    Route::resource('invoices', InvoiceController::class)->middleware('can:mining.view');

    Route::get('settings', [SettingsController::class, 'index'])->name('mining.settings')
        ->middleware('can:mining.manage');
    Route::post('settings', [SettingsController::class, 'update'])->name('mining.settings.update')
        ->middleware('can:mining.manage');
});