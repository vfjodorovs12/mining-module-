<?php

return [
    'mining.view' => 'Permission to view mining statistics and related data.',
    'mining.manage' => 'Permission to manage mining settings, moons, and invoices.',
    'mining.view.detailed' => 'Permission to view detailed mining statistics.',
];