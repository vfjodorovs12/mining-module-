<?php

return [
    'mining' => [
        'name'  => 'Mining',
        'icon'  => 'fa fa-industry',
        'route' => 'mining.statistics',
        'permission' => 'mining.view',
        'children' => [
            [
                'name' => 'Statistics',
                'icon' => 'fa fa-chart-bar',
                'route' => 'mining.statistics',
                'permission' => 'mining.view',
            ],
            [
                'name' => 'Moons',
                'icon' => 'fa fa-moon',
                'route' => 'mining.moons',
                'permission' => 'mining.manage',
            ],
            [
                'name' => 'Invoices',
                'icon' => 'fa fa-file-invoice-dollar',
                'route' => 'mining.invoices',
                'permission' => 'mining.view',
            ],
            [
                'name' => 'Settings',
                'icon' => 'fa fa-cogs',
                'route' => 'mining.settings',
                'permission' => 'mining.manage',
            ],
        ],
    ],
];