@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Общая статистика добычи</h1>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Сводные данные</h5>
            <p>Общее количество добытой руды: <strong>{{ number_format($summary->total_ore) }}</strong></p>
            <p>Всего сессий добычи: <strong>{{ $summary->total_mining_sessions }}</strong></p>
        </div>
    </div>

    <div class="mt-4">
        <a href="{{ route('mining.statistics.detailed') }}" class="btn btn-primary">Детальная статистика (только для администраторов)</a>
    </div>
</div>
@endsection