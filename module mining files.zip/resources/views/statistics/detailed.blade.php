@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Детальная статистика добычи</h1>

    <form method="GET" action="{{ route('mining.statistics.detailed') }}" class="mb-4">
        <div class="row">
            <div class="col-md-4">
                <input type="text" name="character_id" class="form-control" placeholder="ID персонажа" value="{{ request('character_id') }}">
            </div>
            <div class="col-md-4">
                <input type="text" name="ore_type" class="form-control" placeholder="Тип руды" value="{{ request('ore_type') }}">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">Фильтровать</button>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID персонажа</th>
                <th>Тип руды</th>
                <th>Количество</th>
                <th>Дата добычи</th>
            </tr>
        </thead>
        <tbody>
            @foreach($records as $record)
            <tr>
                <td>{{ $record->character_id }}</td>
                <td>{{ $record->ore_type }}</td>
                <td>{{ number_format($record->quantity) }}</td>
                <td>{{ $record->mined_at }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <div class="mt-4">
        {{ $records->links() }}
    </div>
</div>
@endsection